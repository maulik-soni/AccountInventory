import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { WebServicesService } from './../../services/web-services.service';

@Component({
  selector: 'app-payable',
  templateUrl: './payable.component.html',
  styleUrls: ['./payable.component.css'],
})
export class PayableComponent implements OnInit {
search;
mydata =  [];
contents;
  constructor(
    private _webservice : WebServicesService
  ) { }

  ngOnInit():any {
    this.search="uik";
  }
  onSubmit(form:NgForm){
        this._webservice.getpayable(this.search)
      .subscribe( 
        response => {console.log(response)},
        error=>{console.log(error)});
      this.contents=JSON.stringify(this.mydata);
      console.log(this.mydata);
  }

}
