import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// import { DatepickerModule } from 'angular2-material-datepicker';
// import { DatePickerModule } from 'ng2-datepicker';
// import { SelectModule } from 'ng2-select';
import { FormsModule } from '@angular/forms';
// import { DashboardComponent } from'./../dashboard/dashboard.component';
import { DashboardStructureModule } from './../dashboard-structure/dashboard-structure.module';
import { AccountRoutingModule } from './account-routing.module';
// import { NgForm } from '@angular/forms';


import { PayableComponent} from './payable/payable.component';
import { RecievableComponent } from './recievable/recievable.component';

import { WebServicesService } from './../services/web-services.service';


@NgModule({
  imports: [
    CommonModule,
        DashboardStructureModule,
    // DatepickerModule,
    // DatePickerModule,
    // SelectModule,
    FormsModule,

    AccountRoutingModule
  ],
  declarations: [PayableComponent,RecievableComponent],
  providers:[WebServicesService]
})
export class AccountModule { }
