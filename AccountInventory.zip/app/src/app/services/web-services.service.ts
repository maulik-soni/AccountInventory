import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class WebServicesService {
  private base_url = "http://127.0.0.1:8000";
  private apis = {
    salesreport: this.base_url+'/api/salesreport',
    purchasereport:this.base_url+'/api/purchasereport',
    postnewpurchase:this.base_url+'/api/newpurchase',
    postnewsales:this.base_url+'/api/newsales',
    postnewmemoin:this.base_url+'/api/memoin',
    postnewmemoissue:this.base_url+'/api/memoissue',
    purchaseretrun:this.base_url+'/api/purchasereturn',
    salesreturn:this.base_url+'/api/salesreturn',
    purchaseretrunreport:this.base_url+'/api/purchaseretrunreport',
    salesretrunreport:this.base_url+'/api/salesretrunreport',
    memoinreport:this.base_url+'/api/memoinreport',
    memoissuereport:this.base_url+'/api/memoissuereport',
    memoissuechangestatus:this.base_url+'/api/memoissuechangestatus',
    memoinchangestatus : this.base_url+'/api/memoinchangestatus',
    createlabissue : this.base_url+'/api/createlabissue',
    reportlab:this.base_url+'/api/reportlab',
    changelabissuestatus:this.base_url+'/api/changestatus',

    payable:this.base_url+'/api/payable',
    recievable:this.base_url+'/api/recievable',

    newuser:this.base_url+'/api/newuser',
    searchuser:this.base_url+'/api/searchuser',
    showuser:this.base_url+'/api/showuser',
    edituser:this.base_url+'/api/edituser',
    updateuser:this.base_url+'/api/updateuser',
    deleteuser:this.base_url+'/api/deleteuser',


    newcashbbok:this.base_url+'/api/newcashbbok',
    showcashbook:this.base_url+'/api/showcashbook',
    searchcashbook:this.base_url+'/api/searchcashbook',
  };
  
  constructor(private _http:Http) { }
  ///User
  newuser(data){
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    return this._http.post(this.apis.newuser,data,options)
    .map((response:Response) => response.json());
  }

  searchuser(data){
    return this._http.get(this.apis.searchuser+'?'+data.filterby+'='+data.searchterm)
       .map((response:Response) => response.json());
  }

  showuser(data){
    return this._http.get(this.apis.showuser+'?'+data)
    .map((response:Response) => response.json());
  }

  edituser(data){
    return this._http.get(this.apis.edituser+'/'+data)
    .map((response:Response) => response.json());
  }

  updateuser(data){
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    let id=data.id;
    return this._http.put(this.apis.updateuser+'/'+data.id,data,options)
    .map((response:Response) => response.json());
  }

  deleteuser(data){
      return this._http.delete(this.apis.edituser+'/'+data)
    .map((response:Response) => response.json());
  }

  //Cashbook

  newcashbook(data):any{
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    return this._http.post(this.apis.newcashbbok,data,options)
     .map((response:Response) => response.json());
  }

  showcashbook(data){
    return this._http.get(this.apis.showcashbook+'?'+data)
    .map((response:Response) => response.json());
  }

  searchcashbook(data){
    return this._http.get(this.apis.searchcashbook+'?'+data.filterby+'='+data.searchterm)
       .map((response:Response) => response.json());
  }
 ///////////
  getsalesreport(){    
    return this._http.get(this.apis.salesreport)
      .map((response:Response) => response.json());
  }
  getpurchasereport(){    
    return this._http.get(this.apis.purchasereport)
      .map((response:Response) => response.json());
  }
  getpayable(data){
    console.log(this.apis.payable+'?'+data);
    return this._http.get(this.apis.payable+'?'+data)
       .map((response:Response) => response.json());
  }

   getrecievable(data){
    console.log(this.apis.recievable+'?'+data);
    return this._http.get(this.apis.recievable+'?'+data)
       .map((response:Response) => response.json());
  }

 

  // getcashbookdata(){
  //   console.log(this.apis.getcashbookdata);
  //   return this._http.get(this.apis.getcashbookdata)
  //     .map((response:Response) => response.json());
  // }

  postpurchasedata(data){
    console.log(data);
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    this._http.post(this.apis.postnewpurchase,data,options).subscribe();
  }

  


  postsalesdata(data){
    console.log(data);
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    this._http.post(this.apis.postnewsales,data,options).subscribe();
  }

  postmemo(data,memotype){
    console.log(data,memotype);
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    if(memotype == "memoissue"){
      this._http.post(this.apis.postnewmemoin,data,options).subscribe();
    }else{
      this._http.post(this.apis.postnewmemoissue,data,options).subscribe();
    }
    // 
  }

  postmemoissue(data){
    console.log(data);
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    this._http.post(this.apis.postnewmemoissue,data,options).subscribe();
  }

  purchaseReturn(PCS_ID){
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    this._http.post(this.apis.purchaseretrun,PCS_ID,options).subscribe();
  }

  salesReturn(PCS_ID){
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    this._http.post(this.apis.salesreturn,PCS_ID,options).subscribe();
  }

  purchaseretrunreport(){
    console.log(this.apis.purchaseretrunreport);
    return this._http.get(this.apis.purchaseretrunreport)
      .map((response:Response) => response.json());
  }
  
  salesretrunreport(){
    console.log(this.apis.salesretrunreport)
    return this._http.get(this.apis.salesretrunreport)
      .map((response:Response) => response.json());
  }

  fetchpurchase(pcsid){
    return this._http.get(this.apis.purchasereport+"?pcsid="+pcsid)
      .map((response:Response) => response.json()); 
  }

  memoinreport(){
    return this._http.get(this.apis.memoinreport)
      .map((response:Response) => response.json());
  }

  memoissuereport(){
    return this._http.get(this.apis.memoissuereport)
      .map((response:Response) => response.json());
  }

  memoinchangestatus(pcsid){
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    return this._http.post(this.apis.memoinchangestatus+"?pcsid="+pcsid,options);
  }

  changelabissuestatus(pcsid){
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    return this._http.get(this.apis.changelabissuestatus+"?PCS_ID="+pcsid,options);
  }

  createlabissue(data){
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    this._http.post(this.apis.createlabissue,data,options).subscribe();
  }

  reportlab(){
    console.log("GET");
    return this._http.get(this.apis.reportlab)
      .map((response:Response) => response.json());
  }

  memoissuechangestatus(pcsid){
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    return this._http.get(this.apis.memoissuechangestatus+"?pcsid="+pcsid,options);
  }

  dateConversion(date){
    console.log(date);
    var dd = new Date(date).getDate();
    var mm = new Date(date).getMonth() + 1;
    var yyyy = new Date(date).getFullYear();
    var dateString = yyyy + "/" + mm + "/" + dd;
    return dateString;
  }

}
