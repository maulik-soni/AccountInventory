export class SignInFields {
    email: string; 
    password: string; 
}

export const Countries=['India','Indonesia','China'];