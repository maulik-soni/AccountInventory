<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <h1>Helslo</h1>
    @can('delete_user')
        <a href="#">asdhasd</a>
    @endcan
</body>
</html>