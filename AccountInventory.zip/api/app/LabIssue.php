<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class LabIssue extends Model
{
    public $table='lab_issue';
    protected $primaryKey = 'PCS_ID';
}