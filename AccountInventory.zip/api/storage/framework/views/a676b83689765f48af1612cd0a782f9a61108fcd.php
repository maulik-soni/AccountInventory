<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <h1>Helslo</h1>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_user')): ?>
        <a href="#">asdhasd</a>
    <?php endif; ?>
</body>
</html>